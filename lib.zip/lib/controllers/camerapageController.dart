import 'dart:io';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';

class CameraPageController extends GetxController {
  final ImagePicker picker = ImagePicker(); // Use ImagePicker for capturing photos
  var base64img = ''.obs; // Observable for the base64 image
  var camVisible = false.obs; // Observable for camera visibility
  var imagePath = ''.obs;
  var croppedImageFile = Rx<XFile?>(null); // Observable for cropped image
  var croppedImageFiles = <XFile>[].obs;


  var cameraOpen = false.obs; // Flag to track camera open status
  bool _isDisposed = false;

  // Use ImagePicker to pick an image from the camera
  Future<int> captureAndCropImage() async {
    try {
      // Show camera preview and allow capturing image
      final photo = await picker.pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
      );

      if (photo != null && await File(photo.path).exists()) {
        await Future.delayed(const Duration(milliseconds: 300));

        imagePath.value = photo.path;
        camVisible.value = false; // Hide camera preview after capture

        // 🚫 No cropping — directly read and encode image
        final imageBytes = await File(photo.path).readAsBytes();
        croppedImageFile.value = XFile(photo.path);
        croppedImageFiles.add(XFile(photo.path));
        base64img.value = base64.encode(imageBytes);

        debugPrint("✅ Captured image path: ${photo.path}");
        debugPrint("✅ Base64 length: ${base64img.value.length}");

        return 1;
      }
      else {
        return 0; // ❌ cancelled
      }
    } catch (e) {
      if (!_isDisposed) {
        debugPrint("Error capturing image: $e");
      }
      print("Error capturing image: $e");
      return 0; // ❌ error

    }
  }

  // Function to crop the image
  Future<void> _cropImage(XFile? photo) async {
    ///no

    if (_isDisposed || photo == null || !(await File(photo.path).exists())) {
      return;
    }
    try{
        final croppedFile = await ImageCropper().cropImage(
          sourcePath: Platform.isAndroid ? photo.path : photo.path,
          compressFormat: ImageCompressFormat.jpg,

          maxWidth: 1920,
          maxHeight: 1080,
          compressQuality: 50,
          uiSettings: [
            AndroidUiSettings(
              hideBottomControls:false,

              toolbarTitle: 'Cropper',
              toolbarColor: Colors.deepOrange,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: false,
            ),
          ],
        );

        if (croppedFile != null&& !_isDisposed) {
          final imageBytes = await File(croppedFile.path).readAsBytes();
          croppedImageFile.value = XFile(croppedFile.path);
          croppedImageFiles.add(XFile(croppedFile.path)); // Add to the list
          base64img.value = base64.encode(imageBytes); // Update base64 image
          print("Base64 Image: ${base64img.value}");
        }
      }catch(e){
      if (!_isDisposed) {
        Get.snackbar(
          'Alert!',
          "Error: $e",
          overlayBlur: 2.0,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
      }      }


  }

  void clearCroppedImageFile() {
    croppedImageFile.value = null; // Set the value to null
    croppedImageFiles.clear();

  }
  @override
  void onClose() {
    _isDisposed = true;
    super.onClose();
  }
}
