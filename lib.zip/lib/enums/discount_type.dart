enum DiscountType { percentage, priceOff }
