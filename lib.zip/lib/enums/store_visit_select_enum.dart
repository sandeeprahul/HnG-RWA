enum StoreVisitEnum {
  visited,
  notVisited,

}